package com.collegemanagement.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.collegemanagement.dto.DepartmentDTO;
import com.collegemanagement.entity.Department;
import com.collegemanagement.repo.DepartmentRepository;

@Service
public class DepartmentService {
	private final DepartmentRepository departmentRepository;

	@Autowired
	public DepartmentService(DepartmentRepository departmentRepository) {
		this.departmentRepository = departmentRepository;
	}

	public List<Department> getAllDepartments() {
		return departmentRepository.findAll();
	}

	public Department getDepartmentById(Long id) {
		return departmentRepository.findById(id).orElse(null);
	}

	public Department createDepartment(DepartmentDTO departmentDTO) {
		Department department = new Department();
		department.setName(departmentDTO.getName());
		return departmentRepository.save(department);
	}

	public Department updateDepartment(Long id, DepartmentDTO departmentDTO) {
		Department department = departmentRepository.findById(id).orElse(null);
		if (department != null) {
			department.setName(departmentDTO.getName());
			return departmentRepository.save(department);
		}
		return null;
	}

	public void deleteDepartment(Long id) {
		departmentRepository.deleteById(id);
	}

	public List<Department> searchDepartmentsByName(String name) {
		return departmentRepository.findByNameContainingIgnoreCase(name);
	}
}
