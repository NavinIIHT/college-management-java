package com.collegemanagement.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.collegemanagement.dto.StudentDTO;
import com.collegemanagement.entity.Department;
import com.collegemanagement.entity.Student;
import com.collegemanagement.repo.DepartmentRepository;
import com.collegemanagement.repo.StudentRepository;

@Service
public class StudentService {
	private final StudentRepository studentRepository;
	private final DepartmentRepository departmentRepository;

	@Autowired
	public StudentService(StudentRepository studentRepository, DepartmentRepository departmentRepository) {
		this.studentRepository = studentRepository;
		this.departmentRepository = departmentRepository;
	}

	public List<Student> getAllStudents() {
		return studentRepository.findAll();
	}

	public Student getStudentById(Long id) {
		return studentRepository.findById(id).orElse(null);
	}

	public Student createStudent(StudentDTO studentDTO) {
		Student student = new Student();
		student.setName(studentDTO.getName());
		System.out.println(studentDTO.getDepartmentId());
		Department department = departmentRepository.findById(studentDTO.getDepartmentId()).orElse(null);
		System.out.println(department.getName());
		student.setDepartment(department);

		return studentRepository.save(student);
	}

	public Student updateStudent(Long id, StudentDTO studentDTO) {
		Student student = studentRepository.findById(id).orElse(null);
		if (student != null) {
			student.setName(studentDTO.getName());

			Department department = departmentRepository.findById(studentDTO.getDepartmentId()).orElse(null);
			student.setDepartment(department);

			return studentRepository.save(student);
		}
		return null;
	}

	public void deleteStudent(Long id) {
		studentRepository.deleteById(id);
	}

	public List<Student> searchStudentsByName(String name) {
		return studentRepository.findByNameContainingIgnoreCase(name);
	}
}
