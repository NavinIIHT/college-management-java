package com.collegemanagement.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.collegemanagement.dto.TeacherDTO;
import com.collegemanagement.entity.Department;
import com.collegemanagement.entity.Teacher;
import com.collegemanagement.repo.DepartmentRepository;
import com.collegemanagement.repo.TeacherRepository;

@Service
public class TeacherService {
	private final TeacherRepository teacherRepository;
	private final DepartmentRepository departmentRepository;

	@Autowired
	public TeacherService(TeacherRepository teacherRepository, DepartmentRepository departmentRepository) {
		this.teacherRepository = teacherRepository;
		this.departmentRepository = departmentRepository;
	}

	public List<Teacher> getAllTeachers() {
		return teacherRepository.findAll();
	}

	public Teacher getTeacherById(Long id) {
		return teacherRepository.findById(id).orElse(null);
	}

	public Teacher createTeacher(TeacherDTO teacherDTO) {
		Teacher teacher = new Teacher();
		teacher.setName(teacherDTO.getName());

		Department department = departmentRepository.findById(teacherDTO.getDepartmentId()).orElse(null);
		teacher.setDepartment(department);

		return teacherRepository.save(teacher);
	}

	public Teacher updateTeacher(Long id, TeacherDTO teacherDTO) {
		Teacher teacher = teacherRepository.findById(id).orElse(null);
		if (teacher != null) {
			teacher.setName(teacherDTO.getName());

			Department department = departmentRepository.findById(teacherDTO.getDepartmentId()).orElse(null);
			teacher.setDepartment(department);

			return teacherRepository.save(teacher);
		}
		return null;
	}

	public void deleteTeacher(Long id) {
		teacherRepository.deleteById(id);
	}

	public List<Teacher> searchTeachersByName(String name) {
		return teacherRepository.findByNameContainingIgnoreCase(name);
	}
}
